import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(LineElement, CategoryScale, LinearScale, PointElement, Tooltip, Legend);

export default function Home() {
  const data = {
    labels: ["Lun", "Mar", "Mié", "Jue", "Vie"],
    datasets: [
      {
        label: "Valor promedio",
        data: [12, 15, 14, 18, 16],
        borderColor: "#268BC9",
        backgroundColor: "rgba(38,139,201,0.2)",
        tension: 0.3,
        fill: true,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: { display: true, position: "bottom" },
    },
    scales: {
      x: { grid: { color: "rgba(0,0,0,0.05)" } },
      y: { beginAtZero: true, grid: { color: "rgba(0,0,0,0.05)" } },
    },
  };

  return (
    <div className="p-6 text-gray-800">
      <h1 className="text-2xl font-bold mb-2">Panel de Control</h1>
      <p className="text-gray-600 mb-6">
        Bienvenido al sistema de Control de Datos. Aquí puedes consultar el
        estado de tus procesos y acceder a los análisis de control.
      </p>

      {/* Tarjetas de resumen */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="bg-white shadow-md rounded-2xl p-4">
          <h2 className="text-lg font-semibold text-[#268BC9]">
            Procesos activos
          </h2>
          <p className="text-3xl font-bold mt-2">12</p>
        </div>

        <div className="bg-white shadow-md rounded-2xl p-4">
          <h2 className="text-lg font-semibold text-[#268BC9]">
            Último análisis
          </h2>
          <p className="mt-2">X̄–R realizado el 16/10/2025</p>
        </div>

        <div className="bg-white shadow-md rounded-2xl p-4">
          <h2 className="text-lg font-semibold text-[#268BC9]">
            Promedio general
          </h2>
          <p className="text-3xl font-bold mt-2">15.6</p>
        </div>
      </div>

      {/* Gráfico */}
      <div className="bg-white shadow-md rounded-2xl mb-8 p-6">
        <h2 className="text-lg font-semibold text-[#268BC9] mb-4">
          Tendencia semanal
        </h2>
        <Line data={data} options={options} height={120} />
      </div>

      {/* Botones */}
      <div className="flex gap-4">
        <button className="bg-[#268BC9] hover:bg-[#1d72a7] text-white font-medium px-4 py-2 rounded-xl">
          Nuevo Registro
        </button>
        <button className="border border-[#268BC9] text-[#268BC9] hover:bg-[#268BC9]/10 font-medium px-4 py-2 rounded-xl">
          Ver Reportes
        </button>
      </div>
    </div>
  );
}
