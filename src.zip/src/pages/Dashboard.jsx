import { Line, Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  LineElement,
  BarElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Tooltip,
  Legend,
} from "chart.js";


ChartJS.register(
  LineElement,
  BarElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Tooltip,
  Legend
);

function Card({ title, value, color }) {
  return (
    <div className="bg-white shadow-md rounded-2xl p-4">
      <h2 className="text-lg font-semibold" style={{ color }}>
        {title}
      </h2>
      <p className="text-3xl font-bold mt-2">{value}</p>
    </div>
  );
}

export default function Dashboard() {
  // --- Datos ficticios para gráficos ---
  const dataXR = {
    labels: ["Lun", "Mar", "Mié", "Jue", "Vie"],
    datasets: [
      {
        label: "Promedio",
        data: [12, 15, 14, 18, 16],
        borderColor: "#268BC9",
        backgroundColor: "rgba(38,139,201,0.2)",
        tension: 0.3,
        fill: true,
      },
      {
        label: "Límite Superior",
        data: [16, 16, 16, 16, 16],
        borderColor: "#E53E3E",
        borderDash: [5, 5],
        fill: false,
      },
      {
        label: "Límite Inferior",
        data: [10, 10, 10, 10, 10],
        borderColor: "#E53E3E",
        borderDash: [5, 5],
        fill: false,
      },
    ],
  };

  const dataTrend = {
    labels: ["Semana 1", "Semana 2", "Semana 3", "Semana 4"],
    datasets: [
      {
        label: "Promedio mensual",
        data: [14, 15, 13, 16],
        borderColor: "#268BC9",
        backgroundColor: "rgba(38,139,201,0.2)",
        tension: 0.3,
        fill: true,
      },
    ],
  };

  const dataP = {
    labels: ["Proceso A", "Proceso B", "Proceso C", "Proceso D"],
    datasets: [
      {
        label: "Defectos (%)",
        data: [5, 8, 3, 10],
        backgroundColor: "#268BC9",
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: { display: true, position: "bottom" },
    },
    scales: {
      x: { grid: { color: "rgba(0,0,0,0.05)" } },
      y: { beginAtZero: true, grid: { color: "rgba(0,0,0,0.05)" } },
    },
  };

  return (
    <div className="p-6 text-gray-800">
      {/* Encabezado */}
      <h1 className="text-2xl font-bold mb-2">Dashboard de Control</h1>
      <p className="text-gray-600 mb-6">
        Monitorea el estado de tus procesos y analiza los gráficos de control.
      </p>

      {/* Tarjetas de resumen */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
        <Card title="Procesos activos" value="12" color="#268BC9" />
        <Card title="Último análisis" value="X̄–R 16/10/2025" color="#268BC9" />
        <Card title="Promedio general" value="15.6" color="#268BC9" />
        <Card title="Fuera de control" value="2" color="#E53E3E" />
        <Card title="Desviación estándar" value="1.2" color="#268BC9" />
      </div>

      {/* Gráficos de control */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        <div className="bg-white shadow-md rounded-2xl p-6">
          <h2 className="text-lg font-semibold text-[#268BC9] mb-4">X̄–R semanal</h2>
          <Line data={dataXR} options={options} height={120} />
        </div>

        <div className="bg-white shadow-md rounded-2xl p-6">
          <h2 className="text-lg font-semibold text-[#268BC9] mb-4">Tendencia mensual</h2>
          <Line data={dataTrend} options={options} height={120} />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        <div className="bg-white shadow-md rounded-2xl p-6">
          <h2 className="text-lg font-semibold text-[#268BC9] mb-4">Defectos por proceso (P)</h2>
          <Bar data={dataP} options={options} height={120} />
        </div>
      </div>

      {/* Botones de acción */}
      <div className="flex gap-4">
        <button className="bg-[#268BC9] hover:bg-[#1d72a7] text-white font-medium px-4 py-2 rounded-xl">
          Nuevo Registro
        </button>
        <button className="border border-[#268BC9] text-[#268BC9] hover:bg-[#268BC9]/10 font-medium px-4 py-2 rounded-xl">
          Exportar Reporte
        </button>
        <button className="border border-[#268BC9] text-[#268BC9] hover:bg-[#268BC9]/10 font-medium px-4 py-2 rounded-xl">
          Ver Análisis Detallado
        </button>
      </div>
    </div>
  );
}
