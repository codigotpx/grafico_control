import { useState } from "react";
import ControlChart from "../components/ControlChart";
import FileUploader from "../components/FileUploader";
import { constants } from "../utils/constants";
import { calculateCapability } from "../utils/calculations";

export default function Prueba() {
  const [means, setMeans] = useState([]);
  const [ranges, setRanges] = useState([]);
  const [stds, setStds] = useState([]);
  const [limitsX, setLimitsX] = useState(null);
  const [limitsR, setLimitsR] = useState(null);
  const [limitsS, setLimitsS] = useState(null);
  const [capability, setCapability] = useState(null);
  const [chartType, setChartType] = useState("xr"); // ← selector (xr o xs)

  const procesarDatos = (datos) => {
    if (!datos || !Array.isArray(datos) || datos.length === 0) {
      alert("⚠️ No se recibieron datos válidos.");
      return;
    }

    const n = datos[0].length;
    const key = String(n);
    const constantsForN = constants[key];

    if (!constantsForN) {
      alert(`No hay constantes definidas para un tamaño de muestra n=${n}`);
      return;
    }

    const { A2, D3, D4, A3, B3, B4 } = constantsForN;

    // 📊 Calcular medias, rangos y desviaciones estándar
    const medias = datos.map((m) => {
      const suma = m.reduce((a, b) => a + b, 0);
      return parseFloat((suma / m.length).toFixed(2));
    });

    const rangos = datos.map((m) => Math.max(...m) - Math.min(...m));

    const desviaciones = datos.map((m) => {
      const mean = m.reduce((a, b) => a + b, 0) / m.length;
      const variance = m.reduce((s, v) => s + (v - mean) ** 2, 0) / (m.length - 1);
      return Math.sqrt(variance);
    });

    // 📈 Promedios globales
    const promedioX = medias.reduce((a, b) => a + b, 0) / medias.length;
    const promedioR = rangos.reduce((a, b) => a + b, 0) / rangos.length;
    const promedioS = desviaciones.reduce((a, b) => a + b, 0) / desviaciones.length;

    // 🔍 Límites X̄–R
    const UCLx = promedioX + A2 * promedioR;
    const LCLx = promedioX - A2 * promedioR;
    const UCLr = D4 * promedioR;
    const LCLr = D3 * promedioR;

    // 🔍 Límites X̄–S
    const UCLxS = promedioX + A3 * promedioS;
    const LCLxS = promedioX - A3 * promedioS;
    const UCLs = B4 * promedioS;
    const LCLs = B3 * promedioS;

    // 💾 Actualizar estados
    setMeans(medias);
    setRanges(rangos);
    setStds(desviaciones);
    setLimitsX({ UCL: UCLx, LCL: LCLx, CL: promedioX });
    setLimitsR({ UCL: UCLr, LCL: LCLr, CL: promedioR });
    setLimitsS({ UCL: UCLs, LCL: LCLs, CL: promedioS });

    // 📊 Calcular capacidad
    const USL = promedioX + 3 * promedioS;
    const LSL = promedioX - 3 * promedioS;
    const capacidad = calculateCapability(datos, USL, LSL);
    setCapability(capacidad);
  };

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-6">📊 Gráficos de Control X̄–R y X̄–S</h1>

      <FileUploader onDataLoaded={procesarDatos} />

      {/* 🔘 Selector de tipo de gráfico */}
      <div className="mt-6">
        <label className="mr-4 font-medium">Selecciona el tipo de gráfico:</label>
        <select
          value={chartType}
          onChange={(e) => setChartType(e.target.value)}
          className="border rounded-lg px-3 py-2 bg-white"
        >
          <option value="xr">X̄–R (Medias y Rangos)</option>
          <option value="xs">X̄–S (Medias y Desviaciones Estándar)</option>
        </select>
      </div>

      {/* 📈 Render dinámico según selección */}
      <div className="mt-8 space-y-8">
        {chartType === "xr" ? (
          <>
            <h2 className="text-xl font-semibold mb-4 text-blue-600">
              📈 Gráficos de Control X̄–R (Medias y Rangos)
            </h2>
            <div>
              <h3 className="text-lg font-semibold mb-2">Gráfico de Medias (X̄)</h3>
              <ControlChart means={means} limits={limitsX} />
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2">Gráfico de Rangos (R)</h3>
              <ControlChart means={ranges} limits={limitsR} />
            </div>
          </>
        ) : (
          <>
            <h2 className="text-xl font-semibold mb-4 text-green-600">
              📉 Gráficos de Control X̄–S (Medias y Desviaciones Estándar)
            </h2>
            <div>
              <h3 className="text-lg font-semibold mb-2">Gráfico de Medias (X̄)</h3>
              <ControlChart means={means} limits={limitsX} />
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2">Gráfico de Desviaciones Estándar (S)</h3>
              <ControlChart means={stds} limits={limitsS} />
            </div>
          </>
        )}
      </div>

      {/* 📏 Indicadores de capacidad */}
      {capability && (
        <div className="mt-10 border-t pt-6">
          <h2 className="text-lg font-semibold mb-2">Indicadores de Capacidad del Proceso</h2>
          <table className="table-auto border-collapse border border-gray-300 w-full text-center">
            <thead className="bg-gray-100">
              <tr>
                <th className="border p-2">Media (μ)</th>
                <th className="border p-2">Desviación (σ)</th>
                <th className="border p-2">Cp</th>
                <th className="border p-2">Cpk</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border p-2">{capability.mean.toFixed(3)}</td>
                <td className="border p-2">{capability.sigma.toFixed(3)}</td>
                <td className="border p-2">{capability.Cp.toFixed(3)}</td>
                <td className="border p-2">{capability.Cpk.toFixed(3)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
