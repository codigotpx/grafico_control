import { useState } from "react";
import ControlChart from "../components/ControlChart";
import FileUploader from "../components/FileUploader";
import { constants } from "../utils/constants";
import { calculateCapability } from "../utils/calculations";

function Card({ title, children, color }) {
  return (
    <div className="bg-white shadow-md rounded-2xl p-6">
      {title && <h2 className={`text-lg font-semibold mb-4 ${color || "text-[#268BC9]"}`}>{title}</h2>}
      {children}
    </div>
  );
}

// --- Editor de límites ---
function LimitsEditor({ limits, onChange }) {
  if (!limits) return null;

  const handleChange = (e) => {
    const { name, value } = e.target;
    onChange({ ...limits, [name]: parseFloat(value) || 0 });
  };

  return (
    <div className="flex gap-4 mb-4">
      <div>
        <label className="block text-sm font-medium">LCL:</label>
        <input
          type="number"
          name="LCL"
          value={limits.LCL}
          onChange={handleChange}
          className="border rounded-lg px-2 py-1 w-24"
        />
      </div>
      <div>
        <label className="block text-sm font-medium">CL:</label>
        <input
          type="number"
          name="CL"
          value={limits.CL}
          onChange={handleChange}
          className="border rounded-lg px-2 py-1 w-24"
        />
      </div>
      <div>
        <label className="block text-sm font-medium">UCL:</label>
        <input
          type="number"
          name="UCL"
          value={limits.UCL}
          onChange={handleChange}
          className="border rounded-lg px-2 py-1 w-24"
        />
      </div>
    </div>
  );
}

export default function EnterData() {
  const [means, setMeans] = useState([]);
  const [ranges, setRanges] = useState([]);
  const [stds, setStds] = useState([]);
  const [limitsX, setLimitsX] = useState(null);
  const [limitsR, setLimitsR] = useState(null);
  const [limitsS, setLimitsS] = useState(null);
  const [capability, setCapability] = useState(null);
  const [chartType, setChartType] = useState("xr");
  const [inputMode, setInputMode] = useState("file");
  const [manualText, setManualText] = useState("");
  const [controlAlert] = useState(""); 

  const procesarDatos = (datos) => {
    if (!datos || !Array.isArray(datos) || datos.length === 0) {
      alert("⚠️ No se recibieron datos válidos.");
      return;
    }

    const n = datos[0].length;
    const key = String(n);
    const constantsForN = constants[key];

    if (!constantsForN) {
      alert(`No hay constantes definidas para un tamaño de muestra n=${n}`);
      return;
    }

    const { A2, D3, D4, A3, B3, B4 } = constantsForN;

    const medias = datos.map((m) => {
      const suma = m.reduce((a, b) => a + b, 0);
      return parseFloat((suma / m.length).toFixed(2));
    });
    const rangos = datos.map((m) => Math.max(...m) - Math.min(...m));
    const desviaciones = datos.map((m) => {
      const mean = m.reduce((a, b) => a + b, 0) / m.length;
      const variance = m.reduce((s, v) => s + (v - mean) ** 2, 0) / (m.length - 1);
      return Math.sqrt(variance);
    });

    const promedioX = medias.reduce((a, b) => a + b, 0) / medias.length;
    const promedioR = rangos.reduce((a, b) => a + b, 0) / rangos.length;
    const promedioS = desviaciones.reduce((a, b) => a + b, 0) / desviaciones.length;

    const UCLx = promedioX + A2 * promedioR;
    const LCLx = promedioX - A2 * promedioR;
    const UCLr = D4 * promedioR;
    const LCLr = D3 * promedioR;
    const UCLxS = promedioX + A3 * promedioS;
    const LCLxS = promedioX - A3 * promedioS;
    const UCLs = B4 * promedioS;
    const LCLs = B3 * promedioS;

    setMeans(medias);
    setRanges(rangos);
    setStds(desviaciones);
    setLimitsX({ UCL: UCLx, LCL: LCLx, CL: promedioX });
    setLimitsR({ UCL: UCLr, LCL: LCLr, CL: promedioR });
    setLimitsS({ UCL: UCLs, LCL: LCLs, CL: promedioS });

    const USL = promedioX + 3 * promedioS;
    const LSL = promedioX - 3 * promedioS;
    const capacidad = calculateCapability(datos, USL, LSL);
    setCapability(capacidad);
  };

  const handleManualSubmit = () => {
    try {
      const rows = manualText
        .split("\n")
        .map(line => line.trim())
        .filter(line => line)
        .map(line =>
          line
            .replace(/"/g, "")
            .split(",")
            .map(v => {
              const num = parseFloat(v.trim());
              if (isNaN(num)) throw new Error(`Valor inválido: "${v}"`);
              return num;
            })
        );

      procesarDatos(rows);
    } catch (e) {
      alert(`⚠️ Error al procesar los datos: ${e.message}`);
    }
  };

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-bold mb-2">Insertar Datos para Gráficos de Control</h1>
      <p className="text-gray-600 mb-6">Selecciona cómo deseas ingresar los datos: archivo CSV o ingreso manual tipo CSV.</p>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="space-y-6">
          <Card title="Modo de ingreso">
            <select
              value={inputMode}
              onChange={(e) => setInputMode(e.target.value)}
              className="border rounded-lg px-3 py-2 bg-white w-full"
            >
              <option value="file">Archivo CSV</option>
              <option value="manual">Ingreso Manual</option>
            </select>
          </Card>

          <Card title="Tipo de gráfico">
            <select
              value={chartType}
              onChange={(e) => setChartType(e.target.value)}
              className="border rounded-lg px-3 py-2 bg-white w-full"
            >
              <option value="xr">X̄–R</option>
              <option value="xs">X̄–S</option>
            </select>
          </Card>
        </div>

        <div className="space-y-6 lg:col-span-2">
          {inputMode === "file" ? (
            <Card title="Cargar archivo CSV">
              <FileUploader onDataLoaded={procesarDatos} />
            </Card>
          ) : (
            <Card title="Ingreso Manual tipo CSV" color="text-blue-600">
              <textarea
                value={manualText}
                onChange={(e) => setManualText(e.target.value)}
                placeholder="Ingresa tus datos separados por comas, una fila por línea"
                className="border rounded-lg w-full h-48 p-2 text-sm font-mono"
              />
              <button
                onClick={handleManualSubmit}
                className="mt-4 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-xl"
              >
                Procesar Datos
              </button>
            </Card>
          )}

          <Card title={chartType === "xr" ? "Gráficos X̄–R" : "Gráficos X̄–S"} color={chartType === "xr" ? "text-blue-600" : "text-green-600"}>
            {chartType === "xr" ? (
              <>
                <h3 className="text-lg font-semibold mb-2">Medias (X̄)</h3>
                <LimitsEditor limits={limitsX} onChange={setLimitsX} />
                <ControlChart means={means} limits={limitsX} />
                {controlAlert && (
                  <div className="mt-2 p-2 bg-yellow-100 border border-yellow-400 text-yellow-800 rounded-md text-sm">
                    {controlAlert}
                  </div>
                )}

                <h3 className="text-lg font-semibold mb-2">Rangos (R)</h3>
                <LimitsEditor limits={limitsR} onChange={setLimitsR} />
                <ControlChart means={ranges} limits={limitsR} />
              </>
            ) : (
              <>
                <h3 className="text-lg font-semibold mb-2">Medias (X̄)</h3>
                <LimitsEditor limits={limitsX} onChange={setLimitsX} />
                <ControlChart means={means} limits={limitsX} />
                {controlAlert && (
                  <div className="mt-2 p-2 bg-yellow-100 border border-yellow-400 text-yellow-800 rounded-md text-sm">
                    {controlAlert}
                  </div>
                )}

                <h3 className="text-lg font-semibold mb-2">Desviaciones (S)</h3>
                <LimitsEditor limits={limitsS} onChange={setLimitsS} />
                <ControlChart means={stds} limits={limitsS} />
              </>
            )}
          </Card>

          {capability && (
            <Card title="Indicadores de Capacidad">
              <table className="table-auto border-collapse border border-gray-300 w-full text-center">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="border p-2">Media (μ)</th>
                    <th className="border p-2">Desviación (σ)</th>
                    <th className="border p-2">Cp</th>
                    <th className="border p-2">Cpk</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border p-2">{capability.mean.toFixed(3)}</td>
                    <td className="border p-2">{capability.sigma.toFixed(3)}</td>
                    <td className="border p-2">{capability.Cp.toFixed(3)}</td>
                    <td className="border p-2">{capability.Cpk.toFixed(3)}</td>
                  </tr>
                </tbody>
              </table>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
