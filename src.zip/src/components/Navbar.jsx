import { NavLink } from "react-router-dom";
import logo from "../assets/logo_unimag.png";

export default function Navbar() {
  const linkStyle = ({ isActive }) =>
    `block px-4 py-2 rounded-md transition ${
      isActive
        ? "bg-white text-[#268BC9] font-semibold"
        : "text-white hover:bg-[#1F7AB2] hover:text-white"
    }`;

  return (
    <nav className="bg-[#1B3A57] w-56 min-h-screen shadow-lg flex flex-col items-center py-6">
      {/* 🖼️ Imagen + texto alineados horizontalmente */}
      <div className="flex items-center mb-8 px-2 border-b border-white pb-4">
        <img
          src={logo}
          alt="Logo"
          className="w-14 h-14 object-contain rounded-full mr-3"
        />
        <h1 className="text-sm font-semibold text-white leading-tight">
          Control<br />de Datos
        </h1>
      </div>

      {/* 📋 Enlaces de navegación en columna */}
      <div className="flex flex-col gap-2 w-full px-4">
        <NavLink to="/" className={linkStyle}>
          🏠 Inicio
        </NavLink>
        <NavLink to="/dashboard" className={linkStyle}>
            🗂️ Dashboard
        </NavLink>
        <NavLink to="/enterData" className={linkStyle}>
          📊 Insertar datos
        </NavLink>
      </div>
    </nav>
  );
}
