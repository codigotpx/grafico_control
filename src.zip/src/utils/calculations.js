import { constants } from "./constants";

export function calculateXR(data) {
    const means = data.map(row => row.reduce((a, b) => a + b) / row.length);
    const ranges = data.map(row => Math.max(...row) - Math.min(...row));

    const Xbar = means.reduce((a, b) => a + b) / means.length;
    const Rbar = ranges.reduce((a, b) => a + b) / ranges.length;

    const n = data[0].length;
    const { A2, D3, D4 } = constants[n];

    return {
        means,
        ranges,
        limits: {
            XbarLCL: Xbar - A2 * Rbar,
            XbarUCL: Xbar + A2 * Rbar,
            RUCl: D4 * Rbar,
            RLCL: D3 * Rbar,
            Xbar,
            Rbar
        }
    };
}

export function calculateCapability(data, USL, LSL) {
  const allValues = data.flat();
  const mean = allValues.reduce((a, b) => a + b) / allValues.length;
  const sigma = Math.sqrt(
    allValues.reduce((sum, v) => sum + (v - mean) ** 2, 0) / allValues.length
  );

  const Cp = (USL - LSL) / (6 * sigma);
  const Cpk = Math.min((USL - mean) / (3 * sigma), (mean - LSL) / (3 * sigma));

  return { Cp, Cpk, mean, sigma };
}
